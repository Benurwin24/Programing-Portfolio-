public class Sphere {

  private double r;
  

  public Sphere() {
    r=0;
  }

  public void setR(double r) {
    this.r = r;
  }
  public double calcVol() {
    double vol = (4/3)*(3.1415)*((r)*(r)*(r));
    return vol;
  }

  public double calcSurfArea(){
    double sa = 4*(3.1415)*((r)*(r));
    return sa;
  }
}